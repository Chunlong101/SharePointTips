# What is this? 
This script is intended to remove "Everyone except external users" group from a batch of sharepoint online site collections. 

# How to use? 
1. Pls install "PnP PowerShell for SharePoint Online" first before running this script, https://github.com/SharePoint/PnP-PowerShell/releases/download/3.11.1907.0/SharePointPnPPowerShellOnline.msi
2. Download "18450478.zip" then unzip it. 
3. Change "Sites.csv" to meet your requirement, the script will go through all the Urls (sites) in that csv file and remove "Everyone except external users" group from the sites. You could also add extra columns into that csv file as your preference, but the “Url” column is mandatory. 
4. Inside "RemoveEveryoneExceptExternalUsers.ps1", pls change the "$workSpace" variable to the path where you unzip "18450478.zip" to, by default it's "C:\Users\chunlonl\source\repos\Test\18450478". 
5. Run "RemoveEveryoneExceptExternalUsers.ps1", and input the credential of the runner (should be a tenant admin).  
6. Logs can be found from "\Common\Logging\Logs". 

# Pls note 
1. This script does the same as manually removing "Everyone except external users" group from "_layouts/15/people.aspx?MembershipGroupId=0", it's one way trip and cannot be rolledback. If the "Everyone except external users" group is added back to a site collection, this will be inherited by sub-site/documents/etc under the collection and any unique permissions added earlier will not take effect. If needed, unique permissions will need to be re-added manually to the sub-site/documents/etc". 
2. Microsoft doesn't provide production ready scripts, customers need to test/verify/develop this script by themselves. And this script is out of the support scope. 
